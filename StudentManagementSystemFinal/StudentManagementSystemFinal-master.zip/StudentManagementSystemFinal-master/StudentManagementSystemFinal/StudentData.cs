using System.Collections.Generic;

namespace StudentManagementSystemFinal
{
    public static class StudentData
    {
        public static List<Student> Students = new List<Student>();
    }
}
