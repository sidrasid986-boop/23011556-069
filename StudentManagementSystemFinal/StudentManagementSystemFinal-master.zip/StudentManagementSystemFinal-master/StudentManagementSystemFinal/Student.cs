namespace StudentManagementSystemFinal
{
    public class Student
    {
        public string Name { get; set; }
        public int Age { get; set; }
        public string ClassName { get; set; }
    }
}
